
addpath U:\User6\ims28\AKPS\vJan09\code;
addpath U:\User6\ims28\AKPS\vJan09\0538_schmutte_release_req204_20081112;
unemp = 0.06; %calibrated rate of unemployment in the sector
vacs = 0.03;
num_firm_types = 2; %number of latent firm types
num_wrkr_types =2; %number of latent worker types
chi0 = 0.1; %production_low_in_simple

limit_generated = 0;



	
	 xinit=[0	   0.3907162		 0.003210513	   0.9149971
1	    1.461225		 0.003281965	   0.1605483
2	   0.1569723		 0.003230545	   0.8286846
3	    4.432757		 0.003281965	  0.07653671
4	   0.8201617		 0.003281965	   0.3168147
5	  0.06908834		0.0005470867	    5.493026
6	  -0.7812709		 0.003281965	  0.06899904
7	  -0.1138996		 0.002949962	   -1.845572
8	   0.3041648		  0.00309627	    1.407312];
%best value from a previous ASA run

xinit = xinit(:,2);

    xmin= [0,  -5, -2,  0,  0,  -1,-1,-3,0]';
    xmax= [1,  5, 2,  5,  5,   1,9,3,1]';
    xtype=-1*ones(size(xinit));
	
	initparms = [xinit xmin xmax xtype];
    
    sheetin = ['fuzz_moments_20081102.xls'];
    
    W_type = 0;
    est_type = 0;
    model = 4;
    
    for sector =11:15
        seedvalue=round(now*100000);
        modelparms = [unemp,num_firm_types,num_wrkr_types,chi0,vacs];
        asaparms = [seedvalue,limit_generated,sector];
        xstar = AKPS_sims(sheetin,modelparms,asaparms,initparms,W_type,model,est_type,sector);
    end
    