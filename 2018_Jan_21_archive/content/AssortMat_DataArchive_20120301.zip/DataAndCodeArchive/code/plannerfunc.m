function res=plannerfunc(q,x,nu)
%The planner chooses queues to maximize expected aggregate output. This
%function computes expected aggregate output given queues, q, production,
%x, and vacancies in each type of job, nu.

N=length(q)/2;

q1=q(1:N);
q2=q(N+1:2*N);

x1=x(1,:)';
x2=x(2,:)';
expq2=exp(-q2);
expq1=exp(-q1);

temp=expq2.*(1-expq1).*x1+(1-expq2).*x2;

res=-nu'*temp;

res = res/sum(nu); %normalization
