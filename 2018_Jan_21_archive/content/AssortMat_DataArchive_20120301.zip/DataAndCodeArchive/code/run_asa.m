function [fstar,xstar,grad,hessian,state]=run_asa(modelparms,data,W,initparms,asaparms,model)

%Etheta, Epsi, covpsitheta, vartheta,varpsi are Nx1 vectors from the chosen sector
%num_obs is Nx1 that contains number of observations in each size class
%avg_size is the Nx1 vector that contains the size of the firm at the midpoint of each quantile (i.e. the size of 5% firm if doing by deciles)
%xinit is the initial solution used to call ASA
%parameters is a vector of the other parameters used in the model. parameters = [unemp,num_firm_types,seedvalue,limit_generated,sector,num_wrkr_types]
%W is the weighting matrix to be used for GMM estimation

%xstar is the best value found by ASA
%parameters are passed through


%modelparms =
%[unemp,num_firm_types,num_wrkr_types,production_low_in_simple];


	
    
   
   



    

    
  
    % simulated annealing
    % [fstar,xstar,grad,hessian,state] =...
    %  asamin('minimize','cost_function',xinit,xmin,xmax,xtype,cost_parms)
    
    % by way of program ASAMIN
    
    % xinit=[alpha, 
    %     share_of_complex_firms, (constante)
    %     size_coefficient_in_share_of_complex_firms,
    %     delta_production_low_in_complex_vs_simple, ( >= 0 )
    %     production_delta_low_vs_high, ( >= 0 )
    %     size_factor_in_production,
    %     ratio_number_of_vacancies_jobs_filled,
    %     size_coefficient_in_number_of_vacancies_jobs_filled];
   
    %     production_low_in_simple is since version 5 of the program equal to 0.1

  %asaparms = [seedvalue limit_generated sector]
    seedvalue = asaparms(1); 
	limit_generated = asaparms(2);
	%init_parms = [xinit xmin xmax xtype];
	xinit = initparms(:,1);
	xmin = initparms(:,2);
	xmax = initparms(:,3);
	xtype = initparms(:,4);
    asamin('set','limit_generated',limit_generated);
    asamin ('set', 'rand_seed',sin(seedvalue)*1000);
    asamin('set','temperature_ratio_scale',5e-3);
    asamin('set','generated_frequency_modulus',500);
    asamin('set','cost_precision',1e-8);
    asamin('set','cost_parameter_scale_ratio',7);
	sector = asaparms(3);
    asamin ('set', 'asa_out_file', [ 'asa_' int2str(sector) '_' int2str(seedvalue) '.log' ] );
    asamin('set','user_initial_parameters',0);
    asamin('set','test_in_cost_func');

    
    W = W/norm(W);

    [fstar,xstar,grad,hessian,state] =...
        asamin('minimize','cost_function',xinit,xmin,xmax,xtype,modelparms,data,W,model);






