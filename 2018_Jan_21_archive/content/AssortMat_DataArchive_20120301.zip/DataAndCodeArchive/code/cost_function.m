function [residu,flag]=cost_function(parms,modelparms,data,W,model)
%Takes the data, model information, parameters, weighting matrix and returns
%weighted length of the vector of moments
%value of the moment equations. Input is formatted as follows:
%parms =[alpha, 
    %     share_of_complex_firms, (constant)
    %     size_coefficient_in_share_of_complex_firms,
    %     delta_production_low_in_complex_vs_simple, ( >= 0 )
    %     production_delta_low_vs_high, ( >= 0 )
    %     size_factor_in_production,
    %     ratio_number_of_vacancies_jobs_filled,
    %     size_coefficient_in_number_of_vacancies_jobs_filled];
    
 %modelparms = [unemp,num_firm_types,num_wrkr_types,production_low_in_simple,vacancy_rate];
 
 %data = [num_obs avg_size Etheta Epsi covthetapsi VarTheta VarPsi]

tic;

%check parameters for sensibility
flag = parmcheck(parms,modelparms,data,W,model);
residu = 10e15;
f_type = 1;

if (flag == 1)
    [residu1 exitflag]=momentsfunc(parms,modelparms,data,0,model);
    if (exitflag > 0) 
        residu=residu1'*W*residu1;
        f_type=0;
        if isnan(residu)
            flag=0;
            f_type=2;
            residu=10e15;
        % there must be a problem with the parameters, so we set
        % the flag to 0 so that ASAMIN can detect this.
        %if debugprint
        %    disp('Houston, we have a problem with NaN in the residual');
        %end
        end

        if imag(residu)
            flag=0;
            f_type=3;
            residu=real(residu);
        %if debugprint
        %	disp('Imaginary residual');
        %	disp([moments(N+1:3*N/2),moments(3*N/2+1:2*N),moments(2*N+1:5*N/2)]);
        % end
        % there must be a problem with the parameters, so we set
        % the flag to 0 so that ASAMIN can detect this.
        end
    else
        flag=0;
        f_type=-1;
    end
end
disp(sprintf('time = %8.4f, residual = %8.6f, flag = %3i,ftype = %3i',toc,residu,flag,f_type))


