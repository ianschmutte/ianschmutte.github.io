function flag = parmcheck(parms,modelparms,data,W,model)

%parms =[alpha, 
    %     share_of_complex_firms, (constant)
    %     size_coefficient_in_share_of_complex_firms,
    %     delta_production_low_in_complex_vs_simple, ( >= 0 )
    %     production_delta_low_vs_high, ( >= 0 )
    %     size_factor_in_production,
    %     ratio_number_of_vacancies_jobs_filled,
    %     size_coefficient_in_number_of_vacancies_jobs_filled];
    
 %modelparms = [unemp,num_firm_types,num_wrkr_types,production_low_in_simple];
 
 %data = [num_obs avg_size Etheta Epsi covthetapsi VarTheta VarPsi]
 
 chi0 = modelparms(4);
 
 
 avg_size = data(:,2);
 S = length(avg_size);
alpha = parms(1);
delta0 = parms(2);
delta1 = parms(3);
chi2 = parms(4);
chi1 = parms(5);
phi = parms(6);
gamma0 = parms(7);
gamma1 = parms(8);

xi = [0;0];
	if (model == 1)
		xi = [1;0];
	elseif (model == 2)
		xi = [0;1];
    elseif (model == 3)
		xi = [0;0];
	elseif (model == 4)
		xi = [parms(9);1-parms(9)];
	elseif (model == 5)
		xi = [parms(9);1-parms(9)];
	elseif (model == 6)
		xi = [parms(9);1-parms(9)];
	else
		xi = [parms(9),parms(10)];
	end


    x0 = zeros(2,2);
    x0(1,1) = chi0;
    x0(1,2) = chi0+chi2;
    x0(2,1) = chi0+chi1;
    x0(2,2) = chi0+chi1+chi2;
    LCA=kron(x0,ones(1,S))+phi*repmat(log(avg_size'),2,2);
	NCA = exp(LCA);
	HCA = exp(NCA);

	if (model == 1)
		x = LCA;
	elseif (model == 2)
		x = NCA;
    elseif (model == 3)
		x = HCA;
	elseif (model == 4)
		x = xi(1)*LCA+xi(2)*NCA;
	elseif (model == 5)
		x = xi(1)*LCA+xi(2)*HCA;
	elseif (model == 6)
		x = xi(1)*NCA+xi(2)*HCA;
	else
		x = xi(1)*LCA+xi(2)*NCA+(1-xi(1)-xi(2))*HCA;
	end

flag =1;

bad3 = find(x<=0);
if (sum(sum(bad3)) > 0)
    flag = 0;
end