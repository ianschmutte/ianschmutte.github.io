function [varh covhk vark] = corr_global(lambda,chi1,chi2,phi,avg_size)
    
    S = size(avg_size);
    N = sum(lambda);
    lambda1 = lambda(1:2*S);
    lambda2 = lambda(2*S+1:end);
    lambda11 = lambda1(1:S);
    lambda12 = lambda1(S+1:end);
    lambda21 = lambda2(1:S);
    lambda22 = lambda2(S+1:end);
    
    ks_bar = sum((phi*log(avg_size)).*(lambda11+lambda12+lambda21+lambda22))/N;
    
    varh = (sum(lambda1)*sum(lambda2)*(chi2^2))/(N^2);
    
    vark = sum((lambda11+lambda21).*((phi*log(avg_size)-(sum(lambda12+lambda22)/N)-ks_bar).^2) ...
    +(lambda12+lambda22).*((phi*log(avg_size) + chi1 -(sum(lambda12+lambda22)/N)-ks_bar).^2))/N;
    
    covhk = sum(lambda11.*(-sum(lambda2)/N)*chi2.*(phi*log(avg_size)-(sum(lambda12+lambda22)/N)-ks_bar) ...
            + (lambda12.*(-sum(lambda2)/N)*chi2 .*(phi*log(avg_size) + chi1 -(sum(lambda12+lambda22)/N)-ks_bar))...
            + (lambda21.*(sum(lambda1)/N)*chi2.*(phi*log(avg_size)-(sum(lambda12+lambda22)/N)-ks_bar)) ...
            + (lambda22.*(sum(lambda1)/N)*chi2.*(phi*log(avg_size) + chi1 -(sum(lambda12+lambda22)/N)-ks_bar)) ... 
            )/N;