%The following function reads raw data on moments from an excel spreadsheet and converts them to a matlab dataset%

function [data sigma S] = create_input_data(sheetin,sector)
	%sheetin is an excel spreadsheet with a particular structure%
    input_data_tmp=xlsread(sheetin);
    input_data=input_data_tmp(10*(sector-1)+1:10*sector,:);
    idx = find(input_data(:,9)>0); %only take data for valid size classes
	%first moments
	Etheta = input_data(idx,5);
	Epsi = input_data(idx,6);
	%second moments
	covthetapsi = input_data(idx,8);
	vartheta = input_data(idx,7);
	varpsi = input_data(idx,9);
	%number of observations
    num_obs= input_data(idx,4);
	avg_size= input_data(idx,3);
	%read the variance-covariance matrix%
	%Each row is a size class. The cov matrix is stored in cols 13-38 and includes cov between the estimated first and second moments within size class, as well as between those moments and the estimated fraction of observations in that size class We arrange the covariance matrix to correspond to the ordering of the moments. Note that we assume the covariances between estimates of the moments for one size class and those estimated for another size class are zero. Because we arrange the moment vector as m = [Etheta ;Epsi; vartheta; covthetapsi; varpsi; frac] the cov matrix is a 6x6 block matrix with 10x10 diagonal blocks. The diagonal entries in the blocks are the covariance between the moments indicated by the position in the 6x6 block structure for each of the 10 size classes
	covthing = input_data(idx,13:48);
	S = length(Epsi(idx));
	sigma = zeros(6*S,6*S);
	%build upper triangular portion of sigma
	for j = 1:6
		for k = j:6
			sigma((j-1)*10+1:j*10,(k-1)*10+1:k*10) = diag(covthing(:,(j-1)*6+k));
		end
	end
	%copy upper tri into lower tri
	sigma = sigma + tril(sigma',-1);
    
	


    data=[num_obs avg_size Etheta Epsi covthetapsi vartheta varpsi];

