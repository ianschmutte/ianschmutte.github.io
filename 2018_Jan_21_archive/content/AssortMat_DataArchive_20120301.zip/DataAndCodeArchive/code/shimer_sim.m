function [lambda w qsol exitflag] = shimer_sim(mu,nu,x)


M = 2;

N = 20;
%Find model primitives for shimer economy based on the inputs



%%%%%%%%%%%%%%%%%%
%SOLVING THE PLANNERS PROBLEM
%%%%%%%%%%%%%%%%%%
A=[]; % inequality constraints
b=[]; % inequality constraints

% Aeq*q=beq equality constraints : The resource constraint of Shimer's model: sum_n(q[m,n] beta_n)=alpha_m
Aeq=kron(eye(2),nu');
beq=mu;

% q0 initial point
q0 = [mu(1)/nu(1);zeros(N-1,1);mu(2)/nu(1);zeros(N-1,1)];


% lb and ub = lower and upper bounds
lb=zeros(M*N,1);
ub=[];

% nonlinear constraints
nonlcon=[];

options=optimset('MaxFunEvals',30000,'TolFun',1e-8,'TolX',1e-8,'TolCon',1e-12,'MaxIter',800,...
    'Algorithm','active-set','Display','off','Diagnostics','off','MaxSQPIter',1000,'UseParallel','always');

xc = x(1,:);
[xt,It]=sort(xc);
%Keeps everything increasing in employer type
xL=x(2,:);

x=[xt;xL(It)];


    [qsol,fval,exitflag]=...
        fmincon(@(q) plannerfunc(q,x,nu),q0,A,b,Aeq,beq,lb,ub,nonlcon,options);


[temp,Itmoins1]=sort(It);
qsol=[qsol(Itmoins1);qsol(Itmoins1+N)];
x=[x(1,Itmoins1);x(2,Itmoins1)]; %returns x to original order

% compute wages

%eps=1e-7; % formerly a way to 'cheat' around problems associated with
%zeros in queue length. Now we handle NAN associated with the wage equation and  log transform
%explicitly
qsol1=qsol(1:N);
qsol2=qsol(N+1:2*N);
xsol1=x(1,:)';
xsol2=x(2,:)';
W1=qsol1.*exp(-qsol1)./(1-exp(-qsol1)).*xsol1;

W2=qsol2.*exp(-qsol2)./(1-exp(-qsol2)).*((exp(-qsol1)).*xsol1 + (xsol2-xsol1));

W=[W1;W2];
W(find(isnan(W) | imag(W))) = 0;

% salaire en "esp�rance" pa rapport au taux de chomage, calcul � am�liorer �ventuellement
 %w1=log((sum(nu.*(1-exp(-qsol1)).*exp(-qsol2))/mu(1)) *W1 );
 %w2=log((sum(nu.*(1-exp(-qsol2)))/mu(2)) *W2 );
 
w = log(W);

% compute the number of workers of each type working for employers of each type
%
lambda1=nu.*(1-exp(-qsol1)).*exp(-qsol2);
lambda2=nu.*(1-exp(-qsol2));
lambda=[lambda1;lambda2];