function sector = AKPS_post(sector,seedvalue,W_type,model)
load (['newresultat_',int2str(sector), '_', int2str(seedvalue),'_',int2str(model),'_',int2str(W_type)]);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Name everything for convenience
    S = length(data(:,1)); %= number of valid size classes
    k = modelparms(2);
    N = k*S;
    chi0 = modelparms(4);
    sector = asaparms(3);
    seedvalue = asaparms(1);
    alpha = xstar(1);
    delta0 = xstar(2);
    delta1 = xstar(3);
    chi2 = xstar(4);
    chi1 = xstar(5);
    phi = xstar(6);
    gamma0 = xstar(7);
    gamma1 = xstar(8);
    avg_size = data(:,2);
    if (model ==4 || model==5 ||model==6)
        xi = xstar(9);
    elseif (model == 7)
        xi1 = xstar(9);
        xi2 = xstar(10);
    end
    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
    
%Get model primitives based on the parameters and solve the equilibrium

    [mu nu x] = make_model_primitives(xstar,modelparms,data,model);
    [lambda w qsol] = shimer_sim(mu,nu,x);
    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    disp(['Displaying Results for sector ',int2str(sector),' under model ',int2str(model)]);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Get plots of the simulated versus actual moments

    momentsfunc(xstar,modelparms,data,1,model);
    print(gcf,'-djpeg',['graphs_',int2str(sector), '_', int2str(seedvalue),'_',int2str(W_type),'_',int2str(model),'_1']);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%Calculate theoretical second moments of theta and psi along with h and k
lambda1 = lambda(1:N);
lambda2 = lambda(N+1:end);

w1 = w(1:N);
w2 = w(N+1:end);

qsol1=qsol(1:N)+eps;
qsol2=qsol(N+1:2*N)+eps;


%In a world where we compute theta and psi properly%
biglambda = 0;
theta1 = sum((lambda1.*lambda2./(lambda1+lambda2)).*w1)/(sum(lambda1.*lambda2./(lambda1+lambda2)))+biglambda;
theta2 = sum((lambda1.*lambda2./(lambda1+lambda2)).*w2)/(sum(lambda1.*lambda2./(lambda1+lambda2)))+biglambda;
psi = ((lambda1.*(w1-theta1))+(lambda2.*(w2-theta2)))./(lambda1+lambda2) - biglambda;


%%% compute the global correlations
varthetag=sum(lambda1*theta1^2+lambda2*theta2^2)/sum(lambda)...
    -(sum(lambda1*theta1+lambda2*theta2)/sum(lambda))^2;
varpsig=sum((lambda1+lambda2).*psi.^2)/sum(lambda)...
    -(sum((lambda1+lambda2).*psi)/sum(lambda))^2;
covthetapsig=sum(lambda1*theta1.*psi+lambda2*theta2.*psi)/sum(lambda)...
    -(sum(lambda1*theta1+lambda2*theta2)/sum(lambda))...
    *(sum(lambda1.*psi+lambda2.*psi)/sum(lambda));
corrthetapsig=covthetapsig/sqrt(varthetag*varpsig);

classes=mod((1:N)-1,N/2)+1; % les N/2 entreprises sont class�es par paires

numclasses=size(tabulate(classes),1);
vartheta=zeros(numclasses,1);
varpsi=vartheta;
covthetapsi=vartheta;
corrthetapsi=vartheta;
partemploi=vartheta;
emploitotal=sum(lambda);

for sect=1:numclasses,
    idx=find(classes==sect);
    sumlambdaidx=sum(lambda1(idx)+lambda2(idx));
    partemploi(sect)=sumlambdaidx/emploitotal;
    
    vartheta(sect)=sum(lambda1(idx)*theta1^2+lambda2(idx)*theta2^2)/sumlambdaidx...
        -(sum(lambda1(idx)*theta1+lambda2(idx)*theta2)/sumlambdaidx)^2;
    varpsi(sect)=sum((lambda1(idx)+lambda2(idx)).*psi(idx).^2)/sumlambdaidx...
        -(sum((lambda1(idx)+lambda2(idx)).*psi(idx))/sumlambdaidx)^2;
    covthetapsi(sect)=sum(lambda1(idx)*theta1.*psi(idx)+lambda2(idx)*theta2.*psi(idx))/sumlambdaidx...
        -(sum(lambda1(idx)*theta1+lambda2(idx)*theta2)/sumlambdaidx)...
        *(sum(lambda1(idx).*psi(idx)+lambda2(idx).*psi(idx))/sumlambdaidx);
    corrthetapsi(sect)=covthetapsi(sect)/sqrt(vartheta(sect)*varpsi(sect));
end




%compute theoretical productivity components
varh = zeros(S,1);
covhk = zeros(S,1);
vark = zeros(S,1);

for sect = 1:numclasses
    idx=find(classes==sect);
    lam = [lambda1(idx)'; lambda2(idx)'];
    [varh(sect) covhk(sect) vark(sect)] = corr_by_size_class(lam,chi1,chi2);
end

corrhk = covhk./sqrt(varh.*vark);

corractual = data(:,5)./(sqrt(data(:,6).*data(:,7)));

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% figures
% we don't want to do the graphs each time, but they are kept for reference
format short g
format compact
disp('XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX');
    disp(sprintf('alpha = %8.6f',alpha));
    disp(sprintf('delta0 = %8.6f',delta0));
    disp(sprintf('delta1 = %8.6f',delta1));
    disp(sprintf('chi2 = %8.6f',chi2));
    disp(sprintf('chi1 = %8.6f',chi1));
    disp(sprintf('phi = %8.6f',phi));
    disp(sprintf('gamma0 = %8.6f',gamma0));
    disp(sprintf('gamma1 = %8.6f',gamma1));
    if (model ==4 || model==5 ||model==6)
        disp(sprintf('xi = %8.6f',xi));
    elseif (model == 7)
        disp(sprintf('xi1 = %8.6f',xi1));
         disp(sprintf('xi2 = %8.6f',xi2));
    end
    disp(sprintf('residual = %8.6f',fstar));
    disp('Number of workers of each type, mu')
    disp(mu);
    disp('Number of vacancies of each type, nu')
    disp(nu);
    sum_obs = sum(data(:,1));
    disp('theoretical employment rate by size class')
    disp(sum(lambda)/sum(mu));
    disp('theoretical occupancy rate by size class')
    disp((lambda1+lambda2)./nu);
    disp('theoretical global occupancy rate');
    disp(sum(lambda)/sum(nu));
    
    disp('Simulated Covariance of h and k by size class');
    disp(covhk);
    disp('Ratio of covhk to covthetapsi'); %Note, this is algebraically identical to what is commented out below
    disp(covhk./covthetapsi);
    %disp((chi1*chi2/(theta1-theta2))*(psi(1:S)-psi(S+1:end)).^-1);
    figure(7); %Check out how the two covs scale, this is the result of compression 
    plot([data(:,5),covthetapsi,covhk]);
    disp(sprintf('Simulated Global correlation of theta and psi = %8.6f',corrthetapsig));
    [varhg covhkg varkg] = corr_global(lambda,chi1,chi2,phi,avg_size);
    corrhkg = covhkg/sqrt(varhg*varkg);
    disp(sprintf('Simulated Global correlation of h and k = %8.6f',corrhkg));

    disp('Correlations by size class');
    disp('actual,simulated theta psi, simulated h k');
    disp([corractual,corrthetapsi,corrhk]);
    l1 = lambda1(1:10)./lambda1(11:20);
    l2 = lambda2(1:10)./lambda2(11:20);

    figure(2);
    plot(1:10,l1,1:10,l2);
    title('Plots $\frac{\epsilon_{m,(s,1)}}{\epsilon_{m,(s,2)}}$ for $m=1,2$','Interpreter','latex');
    xlabel('Employer Size Class, s')
    figure(3);
    subplot(3,2,1);
    plot(repmat((1:N)',1,2),[x(1,:)',x(2,:)']);
    title('Production');axis tight;
    subplot(3,2,3);
    plot(repmat((1:N)',1,2),[w1,w2]);
    title('(log) Wages');axis tight;
    subplot(3,2,4);
%    plot(repmat((1:N)',1,2),[qsol1,qsol2]);
    semilogy(repmat((1:N)',1,2),[qsol1,qsol2]);
    disp('Application queue lengths');
    disp([qsol1,qsol2]);
    title('q');axis tight;
    subplot(3,2,6);
    plot(repmat((1:N)',1,2),[lambda1,lambda2]);
    title('lambda');axis tight;
    subplot(3,2,2);
    plot((1:N)',nu/sum(nu));
    title('Job distribution');
    %plot((1:N)',psi);
    %title('psi');axis tight;
    subplot(3,2,1);
    legend('Type 1','Type 2',2);
    subplot(3,2,5);
    plot((1:N)',(lambda1*theta1+lambda2*theta2)./(lambda1+lambda2),(1:N)',psi);
    title('theta vs. psi');axis tight;
    
    figure(4);
    stem3(kron([theta1;theta2],ones(N,1)),repmat(psi,2,1),lambda);
    axis tight;
    xlabel('Theta');
    ylabel('Psi');
    zlabel('Lambda');
    title('Person and firm effects');
    
    figure(5);
            plot([corractual,corrthetapsi]);
            %title(['Sector ' int2str(sector)]);
            legend('Observed','Simulated',0);
            xlabel('Employer Size Class, s');
            
    figure(6);
            plot(1:10,corractual,'bs-','LineWidth',3);
            xlabel('Employer Size Class');

    print('-f2','-djpeg',['graphs_',int2str(sector), '_', int2str(seedvalue),'_',int2str(W_type),'_',int2str(model), '_2']);
    print('-f3','-djpeg',['graphs_',int2str(sector), '_', int2str(seedvalue),'_', int2str(W_type),'_',int2str(model),'_3']);
    print('-f4','-djpeg',['graphs_',int2str(sector), '_', int2str(seedvalue),'_',int2str(W_type),'_',int2str(model), '_4']);
    print('-f5','-djpeg',['graphs_',int2str(sector), '_', int2str(seedvalue),'_',int2str(W_type),'_',int2str(model), '_5']);
    print('-f7','-djpeg',['graphs_',int2str(sector), '_', int2str(seedvalue),'_',int2str(W_type),'_',int2str(model), '_7']);
    
    save(['simout_',int2str(sector), '_', int2str(seedvalue),'_',int2str(W_type),'_',int2str(model)]);
 
    %OUTPUT RAW DATA TO AN EXCEL SPREADSHEET%
    xlswrite(['datasheet_sect_',int2str(sector)],data,'A1:G10')
    xlswrite(['datasheet_sect_',int2str(sector)],modelparms([1,4])','A12:A13')
    xlswrite(['datasheet_sect_',int2str(sector)],[xstar;fstar],'A15:A24')
    xlswrite(['datasheet_sect_',int2str(sector)],[qsol1 qsol2],'A26:B45')
    xlswrite(['datasheet_sect_',int2str(sector)],covmat,'A47:I55')
    xlswrite(['datasheet_sect_',int2str(sector)],jacr,'A57:I96')
