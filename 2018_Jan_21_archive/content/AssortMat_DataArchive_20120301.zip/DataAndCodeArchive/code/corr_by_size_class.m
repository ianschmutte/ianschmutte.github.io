function [varh covhk vark] = corr_by_size_class(lambda,chi1,chi2)

    NW = sum(lambda,2);
    NF = sum(lambda,1);
    N = sum(NF);
    varh = prod(NW)*(chi2^2)/(N^2);
    vark = prod(NF)*(chi1^2)/(N^2);
    covhk = chi1*chi2*(lambda(1,1)*NW(2)*NF(2)+lambda(2,2)*NW(1)*NF(1)-lambda(1,2)*NW(2)*NF(1)-lambda(2,1)*NW(1)*NF(2))/(N^3);
   