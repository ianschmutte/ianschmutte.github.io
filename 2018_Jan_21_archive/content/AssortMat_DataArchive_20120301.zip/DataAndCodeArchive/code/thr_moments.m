function [output exitflag] = thr_moments(parms,modelparms,data,model)
%compute the theoretical moments

S = length(data(:,1)); %= number of valid size classes
%M = modelparms(3);
k = modelparms(2);
N = k*S;

[mu nu x] = make_model_primitives(parms,modelparms,data,model);
[lambda w qsol exitflag] = shimer_sim(mu,nu,x);

lambda1 = lambda(1:N);
lambda2 = lambda(N+1:end);

w(find(w==-Inf | w == Inf | imag(w))) = 0; %w = -Inf corresponds to lambda=0. Trying to avoid NaN%

w1 = w(1:N);
w2 = w(N+1:end);


biglambda = 0;
theta1 = sum((lambda1.*lambda2./(lambda1+lambda2)).*w1)/(sum(lambda1.*lambda2./(lambda1+lambda2)))+biglambda;
theta2 = sum((lambda1.*lambda2./(lambda1+lambda2)).*w2)/(sum(lambda1.*lambda2./(lambda1+lambda2)))+biglambda;
psi = ((lambda1.*(w1-theta1))+(lambda2.*(w2-theta2)))./(lambda1+lambda2) - biglambda;
% (correlation within)

classes=mod((1:N)-1,N/2)+1; % les N/2 entreprises sont class�es par paires

numclasses=size(tabulate(classes),1);
vartheta=zeros(numclasses,1);
etheta=vartheta;
epsi=vartheta;
varpsi=vartheta;
covthetapsi=vartheta;
corrthetapsi=vartheta;
partemploi=vartheta;
emploitotal=sum(lambda);

for sect=1:numclasses,
    idx=find(classes==sect);
    sumlambdaidx=sum(lambda1(idx)+lambda2(idx));
    partemploi(sect)=sumlambdaidx/emploitotal;
    
    etheta(sect)=sum(lambda1(idx)*theta1+lambda2(idx)*theta2)/sumlambdaidx;
    epsi(sect)=sum((lambda1(idx)+lambda2(idx)).*psi(idx))/sumlambdaidx;
    vartheta(sect)=sum(lambda1(idx)*theta1^2+lambda2(idx)*theta2^2)/sumlambdaidx...
        -(sum(lambda1(idx)*theta1+lambda2(idx)*theta2)/sumlambdaidx)^2;
    varpsi(sect)=sum((lambda1(idx)+lambda2(idx)).*psi(idx).^2)/sumlambdaidx...
        -(sum((lambda1(idx)+lambda2(idx)).*psi(idx))/sumlambdaidx)^2;
    covthetapsi(sect)=sum(lambda1(idx)*theta1.*psi(idx)+lambda2(idx)*theta2.*psi(idx))/sumlambdaidx...
        -(sum(lambda1(idx)*theta1+lambda2(idx)*theta2)/sumlambdaidx)...
        *(sum(lambda1(idx).*psi(idx)+lambda2(idx).*psi(idx))/sumlambdaidx);
    corrthetapsi(sect)=covthetapsi(sect)/sqrt(vartheta(sect)*varpsi(sect));
end

output=[etheta;epsi;covthetapsi;vartheta;varpsi;partemploi];

