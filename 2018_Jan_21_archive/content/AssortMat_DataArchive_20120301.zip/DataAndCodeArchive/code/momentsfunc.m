function [moment_eqns exitflag] = momentsfunc(parms,modelparms,data,post,model)
%This function returns the difference between the theoretical second
%moments (plus measure of the number of filled vacancies in each size
%class) and the empirical moments. This is the function whose Jacobian is
%required in order to properly calculate standard errors, weighting
%matrices, etc.


%data = [num_obs avg_size Etheta Epsi covthetapsi VarTheta VarPsi]
    unemp = modelparms(1);
    vacs = modelparms(5);
    emp_moments = data(:,3:7); %the empirical first and second moments
    num_obs = data(:,1);
    sum_obs = sum(num_obs);
    emp_frac = num_obs/sum_obs;%empirical measure of fraction of the workforce employed in each size class
    emp_moments = [emp_moments emp_frac];
    emp_moments = emp_moments(:);
    %emp_moments = [emp_moments;unemp;vacs];

    [f exitflag] = thr_moments(parms,modelparms,data,model);

    moment_eqns = f - emp_moments; 

    moment_eqns = moment_eqns(21:end); %ignore first moments

    if (post ~= 0)
         S = length(data(:,1)); %= number of valid size classes
         k = modelparms(2);
         N = k*S;
         disp(['Correlations, observed and estimated in sector ' int2str(post)]);
         
         disp([num_obs,emp_moments(N+1:3*N/2)./sqrt(emp_moments(2*N+1:5*N/2).*emp_moments(3*N/2+1:2*N)),...
         f(N+1:3*N/2)./sqrt(f(2*N+1:5*N/2).*f(3*N/2+1:2*N))]);
     
        disp(['variances (theta,pai), observed and estimated in sector ' int2str(post)]);
        disp([emp_moments(31:50),f(31:50)]);
        figure(1);
            plot([emp_moments(N+1:end),f(N+1:end)]);
            title(['Sector ' int2str(post)]);
            legend('Observed','Simulated',0);

    end

