function [xvals dataout]=response_plots(sector,precision,gridsize)

load (['newresultat_',int2str(sector)]);


%Make Response Data
el = length(xstar);
dataout=zeros(2*gridsize+1,el);
xvals = dataout;
for i=1:el
	for j=-gridsize:gridsize
        curr = xstar;
        curr(i) = curr(i)+(j/precision(i));
        xvals(j+gridsize+1,i) = curr(i);
		if (j ~= 0)	
			dataout(j+gridsize+1,i) = cost_function(curr,modelparms,data,W,model);
		else
			dataout(j+gridsize+1,i) = fstar;
		end
	end
end


%%%%%%%%%%%%%%%%
