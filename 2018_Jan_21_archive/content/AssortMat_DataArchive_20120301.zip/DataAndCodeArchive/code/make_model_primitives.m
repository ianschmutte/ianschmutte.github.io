function [mu nu x] = make_model_primitives(parms,modelparms,data,model)

%Takes the data, model information and model parameters and returns a vector with the
%value of the moment equations. Input is formatted as follows:
%parms =[alpha, 
    %     share_of_complex_firms, (constant)
    %     size_coefficient_in_share_of_complex_firms,
    %     delta_production_low_in_complex_vs_simple, ( >= 0 )
    %     production_delta_low_vs_high, ( >= 0 )
    %     size_factor_in_production,
    %     ratio_number_of_vacancies_jobs_filled,
    %     size_coefficient_in_number_of_vacancies_jobs_filled];

    alpha = parms(1);
    delta0 = parms(2);
    delta1 = parms(3);
    chi2 = parms(4);
    chi1 = parms(5);
    phi = parms(6);
    gamma0 = parms(7);
    gamma1 = parms(8);
	
	xi = [0;0];
	if (model == 1)
		xi = [1;0];
	elseif (model == 2)
		xi = [0;1];
    elseif (model == 3)
		xi = [0;0];
	elseif (model == 4)
		xi = [parms(9);1-parms(9)];
	elseif (model == 5)
		xi = [parms(9);1-parms(9)];
	elseif (model == 6)
		xi = [parms(9);1-parms(9)];
	else
		xi = [parms(9),parms(10)];
	end
	
%modelparms = [unemp,num_firm_types,num_wrkr_types,production_low_in_simple];
    unemp = modelparms(1);
    chi0 = modelparms(4);

%data = [num_obs avg_size Etheta Epsi covthetapsi VarTheta VarPsi]
    

    avg_size = data(:,2);
    %Etheta = data(:,3);
    %Epsi = data(:,4);
    %covthetapsi = data(:,5);
    %VarTheta = data(:,6);
    varpsi = data(:,7);
    S = length(varpsi);
    num_obs = data(:,1);

%Total number of vacancies in the sector
    vacancies=(1+exp((gamma0+gamma1*log(avg_size)))).*num_obs;

% fraction of complex firms
	pi=1./(1+exp(delta0+delta1*log(avg_size)));
    
    nu1 = (1-pi).*vacancies; %simple vacancies by size class;
    nu2 = pi.*vacancies;    %complex vacancies by size class;
    nu = [nu1;nu2];

%make a vector of the number of workers of each type
    sum_obs = sum(num_obs);
    mu=[alpha*sum_obs/(1-unemp);(1-alpha)*sum_obs/(1-unemp)];
    % sum_obs is the number of occupied jobs in the sector
    % alpha = fraction of workers of low type
    % unemp is the unemployment rate in the sector
    
%PRODUCTION TECHNOLOGY

    x0 = zeros(2,2);
    x0(1,1) = chi0;
    x0(1,2) = chi0+chi2;
    x0(2,1) = chi0+chi1;
    x0(2,2) = chi0+chi1+chi2;

%match productivity is x=x0+z*log(avg_size_insector)
LCA=kron(x0,ones(1,S))+phi*repmat(log(avg_size'),2,2);
NCA = exp(LCA);
HCA = exp(NCA);

	if (model == 1)
		x = LCA;
	elseif (model == 2)
		x = NCA;
    elseif (model == 3)
		x = HCA;
	elseif (model == 4)
		x = xi(1)*LCA+xi(2)*NCA;
	elseif (model == 5)
		x = xi(1)*LCA+xi(2)*HCA;
	elseif (model == 6)
		x = xi(1)*NCA+xi(2)*HCA;
	else
		x = xi(1)*LCA+xi(2)*NCA+(1-xi(1)-xi(2))*HCA;
	end