
%set parameters%
function xstar = AKPS_sims(sheetin,modelparms,asaparms,initparms,W_type,model,est_type,sector)
    
	%We estimate with different specification sof the weighting matrix W
	%W_type = 1 means estimate with  W = diag([repmat(num_obs,3,1)/sum(num_obs);ones(S,1)]);
	%W_type =2 means estimate with W = inv(sigma)
	
	%We have 7 models for each sector. The values for parameter 'model'  will perform estimation of each of the following
	%1 - 3 = LCA, NCA, HCA alone
	%4-6 = pairwise LCA, NCA, HCA mixing
	%7 = fully nested LCA, NCA, HCA
	
	%est_type=1 means use ASA
	%=2 means use KNITRO with multiple startpoints
	
	

%GRAB DATA
    
	[data sigma S] = create_input_data(sheetin,sector);
	
	if (S<=2) % we need at least three valid firm sizes for the order condition
        disp(['Sector does not have enough valid size classes']);
        return;
    end
	
	sigma = sigma(2*S+1:end,2*S+1:end); %because we don't estimate using Etheta and Epsi
	
%Decide which kind of weighting we are going to do
	
	if (W_type == 1)
        num_obs=data(:,1);
		W=diag([repmat(num_obs,3,1)/sum(num_obs);ones(S,1)]);
        
    elseif (W_type == 2) 
		cond_sigma = cond(sigma);
		if (cond_sigma > 1e9)
			disp('Warning: The covariance matrix is rather poorly conditioned. Interpret at your own risk');
		end
		W = inv(sigma);
    elseif (W_type == 0)
            W = eye(4*S);
	end
	

	
%SET INPUTS FOR ASA     



disp('commencing ASA NOW!');
clock1 = fix(clock)
%%%%%%%%%%%%%%%%%%%%%
[fstar,xstar,grad,hessian,state]=...
    run_asa(modelparms,data,W,initparms,asaparms,model);


disp('Parameter estimation complete!');
disp('xstar');
disp(xstar);
disp('residual');
disp(fstar);
disp('We started at:');
disp(clock1);

save( ['newresultat_',int2str(asaparms(3)), '_', int2str(asaparms(1)),'_',int2str(model),'_',int2str(W_type)]);


disp('Now computing the Jacobian');

addpath U:\User6\ims28\DERIVESTsuite;
moms = @(x) momentsfunc(x,modelparms,data,0,model);
[jac,err] = jacobianest(moms,xstar);

jacr = real(jac);

disp('Jacobian finished');



outer = (jacr'*W*jacr);
outer = inv(outer);
inner = jacr'*W*sigma*W*jacr;
covmat = outer*inner*outer;

    clear num_obs avg_size Etheta Epsi covthetapsi vartheta varpsi idx t input_data ...
        unemp num_firm_types num_wrkr_types chi0 ...
        limit_generated valid_sizes outer inner Wp jacp sigp;
        
    save( ['newresultat_',int2str(asaparms(3)), '_', int2str(asaparms(1)),'_',int2str(model),'_',int2str(W_type)]);
    
AKPS_post(asaparms(3),asaparms(1),W_type,model);
    
    disp('Covariance Matrix');
    disp(covmat);
    disp('Condition of Covmat');
    disp(cond(covmat));
    disp('condition of Jacobian');
    disp(cond(jac));
    
    