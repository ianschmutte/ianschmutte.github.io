John M. Abowd, Francis Kramarz, Sebastien Perez-Duarte, and Ian M. Schmutte
./DataAndCodeArchive/README.txt
January 2012
---------------
This README describes the data and code included in this archive, which were 
used to generate the results in ``A Formal Test of Assortative Matching in the
Labor Market'' by Abowd, Kramarz, Perez-Duarte, and Schmutte. Questions regarding
the code and data can be addressed to Ian Schmutte, schmutte@uga.edu.


=====
DATA
=====

./0538_schmutte_release_req204_20081112/fuzz_moments_20081102.xls

All of the results presented in the paper were generated from these data using 
the code contained in this archive, as described below. Rows in the dataset
are indexed by NAICS sector (01--20 as referenced in the Web Appendix)
and employer size decile. 

The included variables are:

	nacis_sector
	COUNT - the (fuzzed) number of work-history observations contributing to the
	cell
	size_class - defined from deciles of firm-size distribution
	Etheta - the mean person-effect in the cell
	Epsi - the mean firm-effect in the cell
	vartheta - the variance of person-effects
	varpsi - the variance of firm effects
	covthetapsi - the covariance between theta and psi
	frac - The fraction of observations for the sector in the cell
	stdtheta - the standard deviation of the person-effects
	stdpsi - the standard deviation of the firm effects
	s_1_1--s_6_6 - these are 36 variables that hold the column-major 
	representation of the bootstrapped covariance matrix of the data moments.

=====
CODE
=====

The estimation code run under MATLAB version 7.01 and up, and requires the 
following non-standard extensions:
	-MathWorks Optimization and Statistics toolboxes
	-DERIVESTsuite add-on for numerical differentiation. (http://www.mathworks.com/matlabcentral/fileexchange/13490-adaptive-robust-numerical-differentiation)
	-Lester Ingber's Adaptive Simulated Annealing (ASA) library (http://www.ingber.com/#ASA)
	-the ASAMIN MEX file developed by Shinichi Sakata (http://ssakata.sdf.org/software/)

./runs/sectors11-15/

To run the code, call the file RUNALL.m from this subfolder, making appropriate
modifications to filepaths. (Note: you must also edit one path in ./code/AKPS_sims.m
to point to the location where DERIVESTsuite is installed). All of the 
calculations that generated the results presented in the paper were performed 
using the Research Computing system at the Cornell Institute for Social and 
Economic Research. For reference, we have included the raw diagnostic output 
files associated with estimation for Sector 12 (NAICS 541). 

./code
	Contains MATLAB code used for estimation, which is documented inline.
Execution requires the optimization and statistics toolboxes to run. Our 
compiled version of asamin.mex64 is included in the code archive, but the reader
may need to rebuild the MEX file depending on their system architecture. See the
documentation at Sakata's website, referenced above, for details if necessary.

./results
The main results are contained in spreadsheets included in this folder, one per
NAICS sector, called Equilibrium_sector_NN_LCA-NCA.xls.
When executed from ./runs/sectors11-15/RUNALL.m, the code generates a series
of diagnostic plots and logfiles, together with an Excel spreadsheet, called
datasheet_sect_NN.xls, where NN is the two-digit indicator for the NAICS major
sector. This raw output appears in the included spreadsheets as separate data 
sheets (Sheet 2). Sheet 1 contains an 
easier-to-read rendering of that raw output together with additional 
computations. All of the tables and figures included in the paper are drawn 
directly from these formatted spreadsheets.
